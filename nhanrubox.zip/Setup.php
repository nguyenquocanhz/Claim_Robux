<?php
/**
 * Lấy mã định danh của các kênh YouTube
 *
 * Bước 1: Chọn kênh cần lấy mã định danh
 * Bước 2: F12 để vào thao tác hủy đăng ký hoặc đăng ký 1 lần
 *         (nếu là kênh chính chủ, có thể tìm tại https://www.youtube.com/account_advanced)
 * Bước 3: Tìm mã nhận dạng kênh
 *         - Đối với kênh chính chủ: vào tab "Advanced settings" để tìm mã
 *         - Đối với kênh không chính chủ: vào channel muốn lấy mã, F12 rồi chọn tab "Network"
 * Bước 4: Tìm URL có dạng "https://www.youtube.com/youtubei/v1/browse?key="
 *         - Click vào URL này để chuyển qua tab "Headers"
 *         - Tìm giá trị của "browseId", đây là mã định danh của kênh YouTube đó
 * Bước 5: Thêm mã định danh vào mảng $Channel_ID
 *
 * @author
 *   Nguyễn Quốc Anh
 * @copyright
 *   © 2023 by Nguyễn Quốc Anh. All rights reserved.
 * @contact
 *   Telegram: nguyenquocanhdz1
 */
 
$Channel_ID = array(
    'UCm5V9caoQVbDR59E9LESkrw',
    'UCIuTBz1zVKDxCcWswcVPbeg',
    'UCnkBnfHAGNgLWYu2W008h5g',
    'UCMwN2073L0Nyx0yN1HNhuLQ'
);
$miliseconds = 10000;
?>
